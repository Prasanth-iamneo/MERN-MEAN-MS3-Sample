// config.js
 export const apiUrl = 'http://localhost:8080';
