import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./UserProducts.css";
import axios from "axios";
import { apiUrl } from "../apiconfig.js";
const UserProducts = () => {
  const [showDeletePopup, setShowDeletePopup] = useState(false);
  const [productToBeDelete, setProductToBeDelete] = useState(null);
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortValue, setSortValue] = useState(1);
  const navigate = useNavigate();

  useEffect(() => {

    localStorage.setItem("editId", "");
    console.log("came in grid");
    fun();
  }, [searchTerm, sortValue]);

  async function fun() {
    try {
      const token = localStorage.getItem("token");

      console.log("inside function");
      const productResponse = await axios.post(
        apiUrl+"/medicine/getMedicineByUserId",
        {
          searchValue: searchTerm,
          sortValue: sortValue,
          userId: JSON.parse(localStorage.getItem("userData")).userId,
        },
        { headers: { Authorization: `${token}` } }
      );
console.log("productResponse",productResponse);
      if (productResponse.status == 200) {
        setProducts(productResponse.data);
      }
    } catch (error) {
      navigate("/error");
    }
  }

  const handleDeleteClick = (id) => {
    setProductToBeDelete(id);
    setShowDeletePopup(true);
  };
  async function deletefunction() {
    const productId = productToBeDelete; // The ID of the product you want to delete

 try{
    const token = localStorage.getItem("token");

    let deleteResponse = await axios.delete(
      apiUrl+`/medicine/deleteMedicine/${productId}`,
        
        { headers: { Authorization: `${token}` } }
      );
      if (deleteResponse.status === 200) {
        fun();
      }
      setShowDeletePopup(false);
 }
 catch(error){
navigate("/error")
 }
  }

  return (
    <div>
      <div className={`ProductsList ${showDeletePopup ? "popup-open" : ""}`}>
        <button
          className="styledbutton"
          onClick={() => {
            navigate("/login");
          }}
        >
          Logout
        </button>
        <button
          className="styledbutton"
          onClick={() => navigate("/createproduct")}
        >
          Add new Medicine
        </button>
        <h1>My Medicines</h1>
        {/* Search functionality */}
        <input
         className="searchBar"
          type="text"
          placeholder="Search by product name"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        {/* Table layout */}
        <table>
          <thead>
            <tr>
              <th>Product</th>
              <th>Description</th> 
              <th>
                Price{" "}
                <div>
                  <button
                    className="sortButtons"
                    onClick={() => setSortValue(1)}
                  >
                    ⬆️
                  </button>
                  <button
                    className="sortButtons"
                    onClick={() => setSortValue(-1)}
                  >
                    ⬇️
                  </button>
                </div>
              </th>
              <th>ExpiryDate</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {products.length ? (
              products.map((product) => (
                <tr key={product._id}>
                  <td>{product.product}</td>
                  <td>{product.description}</td>
                  <td>{product.price}</td>
                  <td>{    new Date(product.expiryDate).toLocaleDateString('en-GB')
}</td>
                  <td>
                    <button
                      style={{ backgroundColor: "red", marginRight: "10px"}}
                      onClick={() => {
                        handleDeleteClick(product._id);
                      }}
                    >
                      Delete
                    </button>

                    <button style={{ marginLeft:"10px"} }
                      onClick={() => {
                        localStorage.setItem("editId", product._id);
                        navigate("/createproduct");
                      }}
                    >
                      Edit
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td
                  className="norecord"
                  colSpan={4}
                  style={{ textAlign: "center", verticalAlign: "middle" }}
                >
                  No records found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {showDeletePopup && (
        <div className="delete-popup">
          <p>Are you sure you want to delete?</p>
          <button onClick={deletefunction}>Yes, Delete</button>
          <button
            onClick={() => {
              setShowDeletePopup(false);
            }}
          >
            Cancel
          </button>
        </div>
      )}
    </div>
  );
};

export default UserProducts;
